#!/bin/bash
rsync -av ./ pp11@202.38.86.233:~/mpi_share/workspace/gSA21011162